import "./App.css";
import Navbar from "./Navbar/Navbar";
import Header from "./header/Header";
import Productsidebar from "./ProductSide/Productsidebar";

function App() {
  return (
    <div className="App">
      <Navbar />
      <Header />
    </div>
  );
}

export default App;
